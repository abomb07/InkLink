﻿namespace HelenaGrace.Models
{
    public class Report
    {
        public string email { get; set; }
        public string feedback { get; set; }
    }
}
