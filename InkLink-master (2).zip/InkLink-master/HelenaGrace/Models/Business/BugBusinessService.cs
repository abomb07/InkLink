﻿using HelenaGrace.Models.Data;

namespace HelenaGrace.Models.Business
{
    public class BugBusinessService
    {
        BugDataService service = new BugDataService();

        public bool ReportBug(Bug bug) 
        {
            return service.addNewBug(bug);
        }
    }
}
