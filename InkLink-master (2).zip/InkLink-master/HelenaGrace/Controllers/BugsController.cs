﻿using HelenaGrace.Models;
using HelenaGrace.Models.Business;
using Microsoft.AspNetCore.Mvc;

namespace HelenaGrace.Controllers
{
    public class BugsController : Controller
    {
        BugBusinessService service = new BugBusinessService();

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ReportBug(Bug bug) 
        {
            DesignBusinessService dbs = new DesignBusinessService();

            if (service.ReportBug(bug))
            {
                return View("/Views/Bugs/Report.cshtml", dbs.GetAll());
            }
            else
            {
                ViewData.Add("Fail", "Failed Response...");
                return View("Index");
            }
        }
    }
}
